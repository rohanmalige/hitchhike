//
//  PostInfoPopover.swift
//  HitchHike
//
//  Created by Sonali Bhattacharjee on 4/27/24.
//

import SwiftUI
import Firebase
import FirebaseFirestore

struct PostInfoPopover: View {
    @ObservedObject private var firestoreManager = FirestoreManager()
    let postId: String
    @State private var post: Post?
    
    var body: some View {
        VStack {
            if let post = post {
                Text("From: \(post.from)")
                    .font(.custom("Avenir", size: 18))
                Text("From: \(post.to)")
                    .font(.custom("Avenir", size: 18))
                Text("Desired Split")
            }
        
        }
        .padding()
        .onAppear {
            fetchPost()
            print(postId)
//            print(post.from)
//            print(post.to)
        }
    }
    
    private func fetchPost() {
        firestoreManager.fetchPost(id: postId) { fetchedPost, error in
            print("fetching")
            if let error = error {
                print("Error fetching posts: \(error.localizedDescription)")
            }
            
            if let fetchedPost = fetchedPost {
                post = fetchedPost
            }
        }
    }
}

#Preview {
    PostInfoPopover(postId: "FqpeEyh5OFOlNgvobD1p")
}
