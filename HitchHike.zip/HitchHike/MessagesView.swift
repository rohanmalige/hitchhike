//
//  MessagesView.swift
//  HitchHike
//
//  Created by Lena Ray on 4/27/24.
//

import SwiftUI
import Combine

struct MessagesView: View {
    @ObservedObject private var firestoreManager = FirestoreManager()
    @EnvironmentObject var viewModel: AuthenticationViewModel
    var groupID: String

    var body: some View {
        VStack {
            if let messages = firestoreManager.messages {
                List(messages) { message in
                    Text(message.text)
                }
            } else {
                Text("No messages")
            }
        }
        .onAppear {
            firestoreManager.fetchMessages(groupID: groupID) { fetchedMessages, error in
                print("fetching messages")
                if let error = error {
                    print("Error fetching messages: \(error.localizedDescription)")
                } else if let messages = fetchedMessages {
                    self.firestoreManager.messages = messages
                    print("firestore message count: ", messages.count)
                }
            }
        }
    }
}

//struct MessagesView: View {
//    @EnvironmentObject var viewModel: AuthenticationViewModel
//    
//    var body: some View {
//        Section(header: Text("Chat Rooms")) {
//            ForEach(viewModel.userGroups, id: \.self) { groupID in
//                NavigationLink(destination: ChatView(groupID: groupID)) {
//                    Text(groupID)
//                }
//            }
//        }
//    }
//}

//private var chatRoomsSection: some View {
//    Section(header: Text("Chat Rooms")) {
//        ForEach(viewModel.userGroups, id: \.self) { groupID in
//            NavigationLink(destination: ChatView(groupID: groupID)) {
//                Text(groupID)
//            }
//        }
//    }
//}

//
//struct MessagesView: View {
//    @ObservedObject private var firestoreManager = FirestoreManager()
//    var groupID: String
//    
//    var body: some View {
//        VStack {
//            if let messages = firestoreManager.messages {
//                List(messages) { message in
//                    Text(message.text)
//                }
//            } else {
//                Text("No messages")
//            }
//        }
//        .onAppear {
//            firestoreManager.fetchMessages(groupID: groupID) { fetchedMessages, error in
//                if let error = error {
//                    print("Error fetching messages: \(error.localizedDescription)")
//                } else if let messages = fetchedMessages {
//                    self.firestoreManager.messages = messages
//                }
//            }
//        }
//    }
//}

//#Preview {
//    MessagesView(groupID: "IwKOkFm0jct1wjZ9rM9O")
//}
