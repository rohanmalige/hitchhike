//import SwiftUI
//import Combine
//
//struct ChatView: View {
//    @ObservedObject private var firestoreManager = FirestoreManager()
//    var groupID: String
//
//    var body: some View {
//        VStack {
//            if let messages = firestoreManager.messages {
//                List(messages) { message in
//                    Text(message.text)
//                }
//            } else {
//                Text("No messages")
//            }
//        }
//        .onAppear {
//            firestoreManager.fetchMessages(groupID: groupID) { fetchedMessages, error in
//                if let error = error {
//                    print("Error fetching messages: \(error.localizedDescription)")
//                } else if let messages = fetchedMessages {
//                    self.firestoreManager.messages = messages
//                }
//            }
//        }
//    }
//}
//
//
////struct ChatView: View {
////    let groupID: String
////    
////    var body: some View {
////        ZStack {
////            Color("Background").edgesIgnoringSafeArea(.all)
////            ChatTextView()
////        }
////    }
////}
////
//////// Main Chat View
//////struct ChatView: View {
//////    @ObservedObject private var firestoreManager = FirestoreManager()
//////    @EnvironmentObject var viewModel: AuthenticationViewModel
//////    @EnvironmentObject var userModel: UserModel
//////
//////    var body: some View {
//////        ZStack {
//////            Color("Background").edgesIgnoringSafeArea(.all)
//////            ChatTextView()
//////                .environmentObject(userModel)
//////        }
//////        .onAppear {
//////            userModel.getMessageHistory(groupID: userModel.pairingID)
//////        }
//////    }
//////}
//////
////// Chat Text View with message input and send button
////struct ChatTextView: View {
////    @EnvironmentObject var userModel: UserModel
////    @State private var newMessage: String = ""
////
////    var body: some View {
////        VStack {
////            ScrollView {
////                ForEach(userModel.messages) { message in
////                    ChatBubble(message: message.text, isCurrentUser: message.user == userModel.email)
////                        .padding(message.user == userModel.email ? .leading : .trailing, 60)
//////                        .frame(maxWidth: .infinity, alignment: message.user == userModel.email ? .trailing : .leading)
////                }
////            }
////            HStack {
////                TextField("Type a message...", text: $newMessage)
////                    .textFieldStyle(RoundedBorderTextFieldStyle())
////                    .padding()
////
////                Button(action: sendMessage) {
////                    Image(systemName: "paperplane.fill").foregroundColor(.blue)
////                }
////            }
////        }
////    }
////    
////    func sendMessage() {
////        if !newMessage.isEmpty {
////            userModel.sendMessage(groupID: userModel.pairingID, message: newMessage)
////            newMessage = ""
////        }
////    }
////}
////
////// A simple chat bubble view
////struct ChatBubble: View {
////    var message: String
////    var isCurrentUser: Bool
////
////    var body: some View {
////        Text(message)
////            .padding()
////            .background(isCurrentUser ? Color.blue : Color.gray)
////            .cornerRadius(15)
////            .foregroundColor(.white)
////            .padding(10)
////    }
////}
////
////
////
//////struct ChatView_Previews: PreviewProvider {
//////    static var previews: some View {
//////        ChatView()
//////            .environmentObject(UserModel())
//////    }
//////}
