//
//  RideHistoryView.swift
//  HitchHike
//
//  Created by Lena Ray on 4/27/24.
//

import SwiftUI

struct RideHistoryView: View {
    var body: some View {
        Text("Ride History View")
    }
}

#Preview {
    RideHistoryView()
}
